<?php
	if ( !defined('BASEPATH')) exit('No direct script access allowed'); 


class Departement_model extends CI_Model{
		
	private $id;
	private $id_region;
	private $nom;

	protected $table= 'departement';


	function __construct()
		{
			
		}
		
	// Hydrater un reservation

		public function hydrate(array $donnees){
			foreach ($donnees as $key => $value){
				$method = 'set'.ucfirst($key);
				if (method_exists($this, $method)){
					$this->$method($value);
				}
			}
		}

	//affiche juste tous les departements
		public function lister(){
			$data = $this->db->select('id,id_region,nom')
							->from($this->table)
							->order_by('id','asc')
							->get()
							->result();

			$i=0;
			$donnees['data'] = 'non';	
			
			foreach ($data as $row){
		       	$donnees[$i]['id']=$row->id;
		       	$donnees[$i]['id_region']=$row->id_region;
		       	$donnees[$i]['nom']=$row->nom;
		       	$i++;
		       	$donnees['data']='ok';
			}
			
			$donnees['total']=$i;
			return $donnees;	
		}

	// retourne les departements en fomction de l'id de region recu
		public function departementparregion($id_reg){
			$data = $this->db->select('id,id_region,nom')
							->from($this->table)
							->where('id_region',$id_reg)
							->order_by('id','asc')
							->get()
							->result();

			$i=0;
			$donnees['data'] = 'non';	
			
			foreach ($data as $row){
		       	$donnees[$i]['id']=$row->id;
		       	$donnees[$i]['id_region']=$row->id_region;
		       	$donnees[$i]['nom']=$row->nom;
		       	$i++;
		       	$donnees['data']='ok';
			}
			
			$donnees['total']=$i;
			return $donnees;	
		}


	// setteurs

		public function setId($id){
			$this->id=$id;
		}

		public function setId_region($id){
			$this->id_region=$id;
		}
		
		public function setNom($nom){
			$this->tel1=$nom;
		}
		

	// getteurs

		public function getId(){
			return $this->id;
		}

		public function getId_region(){
			return $this->id_regiom;
		}

		public function getNom(){
			return $this->nom;
		}
}


?>

