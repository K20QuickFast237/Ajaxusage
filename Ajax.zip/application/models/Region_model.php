<?php
	if ( !defined('BASEPATH')) exit('No direct script access allowed'); 


class Region_model extends CI_Model{
		
	private $id;
	private $nom;

	protected $table= 'region';


	function __construct()
		{
			
		}
		
	// Hydrater un reservation

		public function hydrate(array $donnees){
			foreach ($donnees as $key => $value){
				$method = 'set'.ucfirst($key);
				if (method_exists($this, $method)){
					$this->$method($value);
				}
			}
		}

		public function lister(){
			$data = $this->db->select('id,nom')
							->from($this->table)
							->order_by('id','asc')
							->get()
							->result();

			$i=0;
			$donnees['data'] = 'non';	
			
			foreach ($data as $row){
		       	$donnees[$i]['id']=$row->id;
		       	$donnees[$i]['nom']=$row->nom;
		       	$i++;
		       	$donnees['data']='ok';
			}
			
			$donnees['total']=$i;
			return $donnees;	
		}


	// setteurs

		public function setId($id){
			$this->id=$id;
		}
		
		public function setNom($nom){
			$this->tel1=$nom;
		}
		

	// getteurs

		public function getId(){
			return $this->id;
		}

		public function getNom(){
			return $this->nom;
		}
}


?>

