<?php
	if ( !defined('BASEPATH')) exit('No direct script access allowed'); 


class Ville_model extends CI_Model{
		
	private $id;
	private $id_departement;
	private $nom;

	protected $table= 'ville';


	function __construct()
		{
			
		}
		
	// Hydrater un reservation

		public function hydrate(array $donnees){
			foreach ($donnees as $key => $value){
				$method = 'set'.ucfirst($key);
				if (method_exists($this, $method)){
					$this->$method($value);
				}
			}
		}

		public function lister(){
			$data = $this->db->select('id,id_departement,nom')
							->from($this->table)
							->order_by('id','asc')
							->get()
							->result();

			$i=0;
			$donnees['data'] = 'non';	
			
			foreach ($data as $row){
		       	$donnees[$i]['id']=$row->id;
		       	$donnees[$i]['id_departement']=$row->id_departement;
		       	$donnees[$i]['nom']=$row->nom;
		       	$i++;
		       	$donnees['data']='ok';
			}
			
			$donnees['total']=$i;
			return $donnees;	
		}

	// retourne les noms de villes en fomction de l'id de departement recu
		public function villepardepartement($id_dep){
			$data = $this->db->select('id,id_departement,nom')
							->from($this->table)
							->where('id_departement',$id_dep)
							->order_by('id','asc')
							->get()
							->result();

			$i=0;
			$donnees['data'] = 'non';	
			
			foreach ($data as $row){
		       	$donnees[$i]['id']=$row->id;
		       	$donnees[$i]['id_departement']=$row->id_departement;
		       	$donnees[$i]['nom']=$row->nom;
		       	$i++;
		       	$donnees['data']='ok';
			}
			
			$donnees['total']=$i;
			return $donnees;	
		}

	// setteurs

		public function setId($id){
			$this->id=$id;
		}

		public function setId_departement($id){
			$this->id_departement=$id;
		}
		
		public function setNom($nom){
			$this->tel1=$nom;
		}
		

	// getteurs

		public function getId(){
			return $this->id;
		}

		public function getId_departement(){
			return $this->id_departement;
		}

		public function getNom(){
			return $this->nom;
		}
}


?>

