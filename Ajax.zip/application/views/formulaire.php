<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="Ajax Jquery-3.6.0 Codeigniter3 " />
      <meta name="author" content="Kevin TONBONG & FADHIL Abouba for Digital Zangalewa" />
      <title>Ajax_usage</title>
      <!-- Google fonts-->
      <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css" />
      <!-- Core theme CSS (includes Bootstrap)-->
      <link href="<?=css_url('bootstrap.min')?>" rel="stylesheet" />
  </head>

<body style="padding-left: 3%;">

  <div class="content-wrapper">
    <section class="content" >
      <div class="row">
        <div id="page-wrapper">
          <div class="main-page">
            <div class="row-one">
              <div class="panel-body widget-shadow">
                <div class="row"><h3 class="">Ajouter une Ville</h3></div>  
                <div class="box box-default" data-select2-id="16">
                  <div class="box-header with-border">
                    <h3 class="box-title">Town Manager</h3>

                    <div class="box-tools pull-right">
                      <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                      <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
                    </div>
                  </div>
                  <!-- /.box-header -->
                  <div class="box-body" data-select2-id="15">
                    <div class="row">
                      <div class="col-md-6" data-select2-id="14">
                        <div class="form-group" data-select2-id="13">
                          <label>region</label>
                          <select class="form-control select2 choixregion" style="width: 100%;" >
                            <option selected="selected" disabled="disabled" data-select2-id="3">Choix de la Region</option>
                            <?php for ($i=0; $i<$region['total'] ; $i++) { ?>
                                <option value="<?php  echo $region[$i]['id'] ?>"><?php  echo $region[$i]['nom'] ?></option>
                            <?php } ?>   
                            
                          </select>
                        </div>

                        <div class="form-group referentiel" data-select2-id="13">
                          <label>Departement</label>
                          <select class="form-control select2" id="referentiel" style="width: 100%;" >
                            <option selected="selected" disabled="disabled" data-select2-id="3">Choix du Departement</option> 
                            <?php for ($i=0; $i<$departement['total'] ; $i++) { ?>
                                <option value="<?php  echo $departement[$i]['id'] ?>" > <?php  echo $departement[$i]['nom'] ?> </option>
                            <?php } ?>  
                            
                          </select>
                        </div>

                        <div class="form-group session" data-select2-id="13">
                          <label>Ville</label>
                          <select class="form-control select2 " id="session" style="width: 100%;" >
                            <option selected="selected" disabled="disabled" data-select2-id="3">Choix de la Ville</option>
                            <?php for ($i=0; $i<$ville['total'] ; $i++) { ?>
                                <option value="<?php  echo $ville[$i]['nom'] ?>"><?php  echo $ville[$i]['nom'] ?></option>
                            <?php } ?>  
                            
                          </select>
                        </div>
                        
                      </div>
                    </div>
                    <!-- /.row -->
                  </div>
                  <!-- /.box-body -->
                </div>
              </div>  
            </div>
            
            <div class="clearfix"> </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <?= js('jquery-3.6.0.min'); ?>
  <?= js('text'); ?>

  </body>
</html>