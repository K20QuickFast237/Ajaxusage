<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Accueil extends CI_Controller {

		
		public function index()
		{
			$this->loadform();
		}

		
		public function loadform(){

			$data['region'] = $this->Region->lister();
			$data['departement'] = $this->Departement->lister();
			$data['ville'] = $this->Ville->lister();

			$this->load->view('formulaire',$data);
		}

		public function manage_actions(){

			if (isset($_POST['id_region'])) {

				echo json_encode($this->Departement->departementparregion($_POST['id_region']));
			}

			if (isset($_GET['id_region'])) {

				echo json_encode($this->Departement->departementparregion($_GET['id_region']));
			}

			if (isset($_POST['id_departement'])) {

				echo json_encode($this->Ville->villepardepartement($_POST['id_departement']));
			}

			if (isset($_GET['id_departement'])) {

				echo json_encode($this->Ville->villepardepartement($_GET['id_departement']));
			}
			
		}

		
	}
?>
