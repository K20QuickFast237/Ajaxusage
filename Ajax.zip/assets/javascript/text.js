	


$(document).ready(function(){


	$('.choixregion').change(function(){
		var id_region =$('.choixregion').val();
		// console.log(id_region);
		
		// $.ajax()

		var jqxhr = $.ajax({
		  	method: "POST",
		  	url: "Accueil/manage_actions",
		  	data: { id_region: id_region },
		  	dataType : 'json'
		  })
		  .done(function(data) {
			$("#referentiel").empty();
			$("#session").empty();
			// console.log(data.total);
			var sms='<option selected="selected" disabled="disabled" data-select2-id="3">Choix du departement</option>';
		  	for  (var i=0; i < data.total ; i++) {
			  	sms+='<option class="id_ref" value="'+data[i].id+'">'+data[i].nom;
			   	sms+='</option>';
			}
			sms+='</select>';
		   	// console.log("debut ma data: "+data.id_region+" :fin ma data");

			$("#referentiel").append($(sms));
			$("#session").append('<option selected="selected" disabled="disabled" data-select2-id="3">Choix de la Ville</option>');
		  })
		  .fail(function(data) {
		  	console.log(data);
			// console.log("je suis ici 1"); 
		  })
		  .always(function() {
		    // alert( "complete" );
		  });

		}
	);

	$('#referentiel').change(function(){
		var id_departement =$('#referentiel').val();
		// console.log(id_departement);
		
	 	// $.ajax()

		var jqxhr = $.ajax({
		  	method: "POST",
		  	url: "Accueil/manage_actions",
		  	data: { id_departement: id_departement },
		  	dataType : 'json'
		  })
		  .done(function(data) {
	  		$("#session").empty();
	 		// $("#session").remove();
			var sms='<option selected="selected" disabled="disabled" data-select2-id="3">Choix de la Ville</option>';
		  	for  (var i=0; i < data.total ; i++) {
			  	sms+='<option class="id_ref" value="'+data[i].nom+'">'+data[i].nom;
			   	sms+='</option>';
			}
			sms+='</select>';

			$("#session").append($(sms));
		  })
		  .fail(function(data) {
		  	console.log(data);
			// console.log("je suis ici 2"); 
		  })
		  .always(function() {
	 	    // alert( "complete" );
		  });

		}
	);	


});